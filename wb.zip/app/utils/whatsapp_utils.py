import json
import requests
from dotenv import load_dotenv
import os
from app.utils.llm_utils import generate_llm_response
from app.utils.database import add_or_update_user
load_dotenv()

ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
RECIPIENT_NUMBER = os.getenv("RECIPIENT_NUMBER")
PHONE_NUMBER_ID = os.getenv("PHONE_NUMBER_ID")

VERSION = os.getenv("VERSION")
# lang_selection = ""
email = None
lang_selection= ""

def get_text_message_input(recipient, text):
    return json.dumps(
        {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": recipient,
            "type": "text",
            "text": {"preview_url": False, "body": text},
        }
    )

def send_message(data):
    headers = {
        "Content-type": "application/json",
        "Authorization": f"Bearer {ACCESS_TOKEN}",
    }

    url = f"https://graph.facebook.com/{VERSION}/{PHONE_NUMBER_ID}/messages"

    response = requests.post(url, data=data, headers=headers, verify=False)
    if response.status_code == 200:
        print("Status:", response.status_code)
        print("Content-type:", response.headers["content-type"])
        print("Body:", response.text)
        return response
    else:
        print(response.status_code)
        print(response.text)
        return response


def process_whatsapp_message(body):
    # Check if the webhook request contains a message
    message = (body.get("entry", [{}])[0]
    .get("changes", [{}])[0]
    .get("value", {})
    .get("messages", [{}])[0])
    global lang_selection,email


    # Check if the incoming message contains text
    if message.get("type") == "text":
        try:
            # Get the incoming message text
            incoming_message = message["text"]["body"]

            if incoming_message == "Hi" or incoming_message == "hi":
                message_data = get_language_option_input(recipient = message["from"])

            elif "@" in incoming_message and lang_selection == "en":
                email = incoming_message
                message_data = get_text_message_input(
                    recipient=message["from"],
                    text="Enter your name, Example: (N)John Doe"
                )
            elif "(N)" in incoming_message and lang_selection == "en" :
                name = incoming_message.replace("(N)","")
                add_or_update_user(message["from"],name, email)
                message_data = get_text_message_input(
                    recipient=message["from"],
                    text="Thank u your details has been saved"
                )
            elif "@" in incoming_message and lang_selection == "es":
                email = incoming_message
                message_data = get_text_message_input(
                    recipient=message["from"],
                    text="Introduce tu nombre, Ejemplo: (N)John Doe"
                )
            elif "(N)" in incoming_message and lang_selection == "es" :
                name = incoming_message.replace("(N)","")
                add_or_update_user(message["from"],name, email)
                message_data = get_text_message_input(
                    recipient=message["from"],
                    text="Gracias, tus datos han sido guardados"
                )

            else:

                response_text =  generate_llm_response(incoming_message)
                # Prepare the message data
                message_data = get_text_message_input(
                    recipient=message["from"],
                    text=response_text
                )
            # Send the message
            send_message(message_data)

            # Mark message as read
            read_data = json.dumps({
                "messaging_product": "whatsapp",
                "status": "read",
                "message_id": message["id"]
            })
            send_message(read_data)
            return 200
        except Exception as e:
            print(f"Error processing message: {str(e)}")
            return 500

    elif message.get("type") == "interactive":
        selection = message["interactive"]["button_reply"]["title"]
        if selection == "English":
            lang_selection = "en"
            message_data = get_text_message_input(
                recipient=message["from"],
                text="Enter your email"
            )
            send_message(message_data)
        elif selection == "Spanish":
            lang_selection = "es"
            message_data = get_text_message_input(
                recipient=message["from"],
                text="Ingrese su correo electrónico"
            )
            send_message(message_data)


    return 200


def get_language_option_input(recipient):
    return json.dumps(
        {
            "messaging_product": "whatsapp",
            "to": recipient,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {
                    "text": "Please select your preferred language:"
                },
                "action": {
                    "buttons": [
                        {
                            "type": "reply",
                            "reply": {
                                "id": "en",
                                "title": "English"
                            }
                        },
                        {
                            "type": "reply",
                            "reply": {
                                "id": "es",
                                "title": "Spanish"
                            }
                        }
                    ]
                }
            }
        })

from app.logs.logger import logging
import os


logger = logging.getLogger(__name__)
logger.debug("Starting")